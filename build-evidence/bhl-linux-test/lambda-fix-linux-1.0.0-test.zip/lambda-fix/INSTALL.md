# Lambda-fix 1.0.0 - Linux test build (not tested in game)

Built from commit a09d490, the same source as the Windows 1.0.0 release.
Built with the Zig toolchain (32-bit x86, GLIBC up to 2.17). The engine binary was not available in the build environment, so the game has not been run with this package.

## Contents

- `cl_dlls/client.so`: client library. Needs `libSDL2-2.0.so.0` on the system.
- `dlls/hl.so`: server library for this mod. `liblist.gam` points to it.
- Everything else is the same as the Windows package: UI files, configs, and `liblist.gam`.

## Install

1. Install your own Half-Life with the `valve/` and `gearbox/` folders.
2. Copy the `lambda-fix/` folder from this zip next to them.
3. Start the game with `lambda-fix` as the mod directory, following how your engine build selects mods.
