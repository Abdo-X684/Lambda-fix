# Lambda-fix: Lambda + Opposing Force (Linux, test build)

This package is a separate game folder, `gearbox_addon`, next to your `valve` and `gearbox` folders.
It uses your installed Opposing Force for maps, models, sounds, and music. Your `gearbox` folder is not changed.

**Test build.** Built from the same source as Lambda-fix 1.0.0 (Windows), but not run in the game yet.

## Install

1. Install Half-Life: Opposing Force.
2. Unzip this package into the main Half-Life folder, next to `valve/` and `gearbox/`.
   It should end up at `Half-Life/gearbox_addon/`.
3. Launch with `-game gearbox_addon`.

## Requirements

- 32-bit x86 Linux with GLIBC 2.17 or newer.
- `libSDL2-2.0.so.0` installed on the system (the client library needs it).

## What is inside

- `gearbox_addon/cl_dlls/client.so`: Lambda client with the Opposing Force weapons.
- `gearbox_addon/dlls/opfor.so`: server library built from the same source.
- `gearbox_addon/liblist.gam`: game definition. It loads `../gearbox_addon/dlls/opfor.so`.
- `gearbox_addon/op4weapons.cfg` and `gearbox_addon/cfg/op4weapons.cfg`: optional cheat script (needs `sv_cheats 1`).
- `LICENSES/`: license files.
