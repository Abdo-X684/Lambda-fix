"ui/resource/HudAmmoSecondary.res"
{
    "HudAmmoSecondaryPanel"
    {
        "ControlName"                "CHudAmmoSecondaryPanel"
        "fieldName"                  "HudAmmoSecondaryPanel"
        "xpos"                       "r68"
        "ypos"                       "r58"
        "wide"                       "48"
        "tall"                       "20"
        "autoResize"                 "0"
        "pinCorner"                  "0"
        "RoundedCorners"             "15"
        "pin_corner_to_sibling"      "0"
        "pin_to_sibling_corner"      "0"
        "visible"                    "0"
        "enabled"                    "1"
        "tabPosition"                "0"
        "PaintBackgroundType"        "2"

        "bgcolor_override"           "0 0 0 96"

        // Ammo icon position
        "ammoicon_xpos"              "30"
        "ammoicon_ypos"              "4"
        "ammoicon_wide"              "12"
        "ammoicon_tall"              "12"
    }
    "Ammo"
    {
        "ControlName"                "Label"
        "fieldName"                  "Ammo"
        "fgcolor_override"           "255 160 0 255"
        "xpos"                       "4" [$WINDOWS]
        "xpos"                       "6" [!$WINDOWS]
        "ypos"                       "0"
        "wide"                       "24" [$WINDOWS]
        "wide"                       "27" [!$WINDOWS]
        "tall"                       "22"
        "autoResize"                 "0"
        "pinCorner"                  "0"
        "RoundedCorners"             "15"
        "pin_corner_to_sibling"      "0"
        "pin_to_sibling_corner"      "0"
        "visible"                    "1"
        "enabled"                    "1"
        "tabPosition"                "0"
        "Font"                       "HudNumbersSmall"
        "labelText"                  "000"
        "textAlignment"              "east"
        "dulltext"                   "0"
        "brighttext"                 "0"
        "wrap"                       "0"
        "centerwrap"                 "0"
        "textinsetx"                 "5"
        "textinsety"                 "0"
        "auto_wide_tocontents"       "0"
        "use_proportional_insets"    "0"
    }
    "AmmoGlow"
    {
        "ControlName"                "Label"
        "fieldName"                  "AmmoGlow"
        "fgcolor_override"           "255 160 0 255"
        "xpos"                       "4" [$WINDOWS]
        "xpos"                       "6" [!$WINDOWS]
        "ypos"                       "0"
        "wide"                       "24" [$WINDOWS]
        "wide"                       "27" [!$WINDOWS]
        "tall"                       "22"
        "autoResize"                 "0"
        "pinCorner"                  "0"
        "RoundedCorners"             "15"
        "pin_corner_to_sibling"      "0"
        "pin_to_sibling_corner"      "0"
        "visible"                    "1"
        "enabled"                    "1"
        "tabPosition"                "0"
        "Font"                       "HudNumbersSmallGlow"
        "labelText"                  "00"
        "textAlignment"              "east"
        "dulltext"                   "0"
        "brighttext"                 "0"
        "wrap"                       "0"
        "centerwrap"                 "0"
        "textinsetx"                 "5"
        "textinsety"                 "0"
        "auto_wide_tocontents"       "0"
        "use_proportional_insets"    "0"
    }
    "AmmoBg"
    {
        "ControlName"                "Label"
        "fieldName"                  "AmmoBg"
        "fgcolor_override"           "128 128 128 16"
        "xpos"                       "4" [$WINDOWS]
        "xpos"                       "6" [!$WINDOWS]
        "ypos"                       "0"
        "wide"                       "24" [$WINDOWS]
        "wide"                       "27" [!$WINDOWS]
        "tall"                       "22"
        "autoResize"                 "0"
        "pinCorner"                  "0"
        "RoundedCorners"             "15"
        "pin_corner_to_sibling"      "0"
        "pin_to_sibling_corner"      "0"
        "visible"                    "1"
        "enabled"                    "1"
        "tabPosition"                "0"
        "Font"                       "HudNumbersSmall"
        "textAlignment"              "east"
        "dulltext"                   "0"
        "brighttext"                 "0"
        "wrap"                       "0"
        "centerwrap"                 "0"
        "textinsetx"                 "5"
        "textinsety"                 "0"
        "auto_wide_tocontents"       "0"
        "use_proportional_insets"    "0"
    }
}
