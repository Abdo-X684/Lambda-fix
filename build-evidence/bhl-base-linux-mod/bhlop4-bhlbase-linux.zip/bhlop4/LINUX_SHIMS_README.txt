cl_dlls/libtier0.so and cl_dlls/libvstdlib.so are CLEAN-ROOM replacements (source: tools/linux_shims/).
They are not Valve files. They provide the 17 symbols the BHL client imports from tier0/vstdlib,
so the client no longer needs Valve's own copies. Limits:
- Msg/Warning go to stdout/stderr, not the in-game console.
- _pcre_default_tables is zeroed: regex character classes may behave incorrectly.
- Asserts are non-fatal.
NOT TESTED IN GAME.

Fix applied: client.so RUNPATH was missing, so the loader never looked in cl_dlls/ for
libtier0.so. RUNPATH is now $ORIGIN (set with patchelf). Nothing else in client.so changed.
