# BugfixedHL + Opposing Force (bhlop4) — Linux

## خطوات التشغيل

1. ثبّت Half-Life: Opposing Force. يجب أن يكون مجلد `gearbox/` موجوداً بجانب `valve/`.
2. احذف أي مجلد `bhlop4` قديم.
3. فكّ هذه الحزمة داخل مجلد اللعبة الرئيسي، بجانب `valve/` و`gearbox/`.
   مثال: `game/bhlop4/`.
4. شغّل اللعبة بخيار `-game bhlop4` (حسب سكربت `hl.sh` عندك).

## ما تحتاجه

- مكتبة SDL2 مثبتة على النظام (`libSDL2-2.0.so.0`).
- Half-Life: Opposing Force الأصلية (مصدر الخرائط والنماذج والأصوات).

## ماذا تحتوي الحزمة

- `cl_dlls/client.so`: عميل BugfixedHL مع أسلحة OP4، ومُبنى بتحسين `-O2`.
  يعتمد على tier0 وvstdlib مدمجين داخله (انظر `LINUX_SHIMS_README.txt`).
- الخادم: يُستخدم `gearbox/dlls/opfor.so` الأصلي من اللعبة المثبتة.
- `ui/resource/`: واجهات BHL، وفيها قائمة Advanced بدون خيار التحديث التلقائي،
  واللون الافتراضي للـHUD أخضر.
- `resource/bhlop4_english.txt`: ملف الترجمة الإنجليزي لنصوص القوائم.
- `LICENSES/`: تراخيص GPL-3.0 لـBugfixedHL، ورخصة Valve للـSDK، ورخصة MIT لأدوات الدمج.

## ملاحظات

- الحزمة لا تحتوي على أصول Valve. تُقرأ الخرائط والنماذج من `gearbox/`.
- الموسيقى لم تُختبر على لينكس بعد.
- إن ظهر خطأ، أرسل آخر أسطر السجل كما ظهرت.

---

## English (short)

Install Half-Life: Opposing Force first, then unpack this folder next to `valve/`
and `gearbox/`. Delete any old `bhlop4` folder first. Launch with `-game bhlop4`.
Requires SDL2 installed on the system. The server is the stock `gearbox/dlls/opfor.so`.
This package does not bundle any Valve assets.
