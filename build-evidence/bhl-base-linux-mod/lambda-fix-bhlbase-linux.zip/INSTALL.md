# Lambda-fix: Lambda + Opposing Force (Linux)

This package is an overlay for your installed Opposing Force. It does not create a new game folder.
The game runs as `gearbox`, so models, sounds, maps, and music come from your own OP4 install.

## Install

1. Install Half-Life: Opposing Force.
2. Back up your `gearbox/` folder (copy it somewhere safe). This package replaces a few files in it.
3. Unzip this package into the main game folder, next to `valve/` and `gearbox/`.
   The zip contains a `gearbox/` folder. Merge it, and overwrite files when asked.
4. Launch Opposing Force as usual, or start it with `-game gearbox` (for example through your `hl.sh`).
   Typing `gamedir` in the console should print `gearbox`.

## Requirements

- Linux x86 (the client is a 32-bit `.so`). glibc 2.17 or newer.
- SDL2 installed on the system (`libSDL2-2.0.so.0`).
- Half-Life: Opposing Force installed.

## What is inside

- `gearbox/cl_dlls/client.so`: Lambda client (based on BugfixedHL) with the Opposing Force weapons,
  built with `-O2`. It links its own tier0/vstdlib replacements (see `LINUX_SHIMS_README.txt`).
- The server is the stock `gearbox/dlls/opfor.so` from your installed game. This package does not replace it.
- `gearbox/ui/`, `gearbox/resource/`: BHL menus and the English menu text.
  The Advanced > About page has no auto-update option.
- `gearbox/delta.lst`: network field table used by this client build.
- `gearbox/op4weapons.cfg` and `gearbox/cfg/op4weapons.cfg`: optional cheat script (needs `sv_cheats 1`).
- `LICENSES/`: GPL-3.0 (BugfixedHL), Valve Half-Life 1 SDK License, and MIT (build tools).
  `NOTICE.txt` explains the source of each part.

## Defaults

- Main HUD color, HUD numbers, and crosshair use the original Opposing Force green (0 160 0).
  The first start with this build sets these once. You can change them later in the Advanced menu.
- `sv_cheats` is set to 0 at every start.

## What changed in this build (not yet tested in game)

- Advanced > HUD Color > "Main color": default is the original OP4 green (0 160 0). Existing settings are reset to green once.
- Crosshair default color: original OP4 green (0 160 0).
- `sv_cheats` is set to 0 at every start.
- Spore Launcher: its weapon name is set on the client, which the other OP4 weapons already had.
- Weapon prediction: ammo type and count are kept per active weapon. Before, every weapon object received the active weapon's ammo values.
- The Sniper / Spore Launcher / Shock Roach mix-up is NOT confirmed fixed. Please test it (see below).

## Weapon test (please report each line)

1. Pick up / select Sniper Rifle: does it fire as a sniper rifle (bullet, scope, sound, model in hand)?
2. Select Spore Launcher: does it fire spores (projectile, sound, model in hand)?
3. Select Shock Roach / Shock Rifle: does it fire the shock rifle (beam, roach, model in hand)?
4. Does the ammo count go down and up correctly for each weapon? Does the HUD icon match the weapon?
5. Any console errors or crashes? Send the last lines of the console.

## Notes

- This package contains no Valve assets. Maps, models, and sounds come from `gearbox/`.
- Music comes from your installed OP4 `gearbox/media`. No MP3 files are in this package.
- This Linux package was built in a Linux sandbox and was not run in a game session by the maintainer.
  Test results are listed in `RUNTIME_TESTS.md`. Only what was reported as working is marked as working.
- To undo: restore your backup of `gearbox/`.
- If you get an error, send the last lines of the console output.
