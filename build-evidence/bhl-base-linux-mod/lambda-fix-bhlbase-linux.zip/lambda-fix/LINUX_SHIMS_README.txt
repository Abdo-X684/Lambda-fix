client.so is built WITH the clean-room tier0/vstdlib replacements linked inside it
(source: tools/linux_shims/, build: tools/build_bhl_base.py). No separate libtier0.so or
libvstdlib.so is needed; client.so NEEDs only libSDL2, libm, libc, libpthread, libdl, ld-linux.
Limits: Msg/Warning go to stdout/stderr (not the in-game console); asserts are non-fatal. pcre tables are the real PCRE default tables.
NOT TESTED IN GAME.
