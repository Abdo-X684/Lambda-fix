# Lambda-fix: Lambda + Opposing Force (Windows)

This package is a separate game folder, `gearbox_addon`, next to your `valve` and `gearbox` folders.
It uses your installed Opposing Force for maps, models, sounds, and music. Your `gearbox` folder is not changed.

## Install

1. Install Half-Life: Opposing Force (Steam or an original copy).
2. Unzip this package into the main Half-Life folder, next to `valve\` and `gearbox\`.
   The zip contains a `gearbox_addon\` folder. It should end up at `Half-Life\gearbox_addon\`.
3. Launch with `hl.exe -game gearbox_addon`.
   Typing `game` or `gamedir` in the console should show `gearbox_addon`.

## Requirements

- Windows 10 or 11. The engine and this client DLL are both 32-bit (Win32).
- Half-Life: Opposing Force installed.
- No separate SDL2 install is needed. The client DLL does not import SDL2.dll.

## What is inside

- `gearbox_addon\cl_dlls\client.dll`: Lambda client (based on BugfixedHL) with the Opposing Force weapons,
  built with MSVC 2022 (Win32). Source: `bhl-op4/` in the Lambda-fix repository.
- `gearbox_addon\dlls\opfor.dll`: server DLL built from the same `bhl-op4/` source (Windows, Win32).
- `gearbox_addon\liblist.gam`: game definition. It loads `gearbox_addon\dlls\opfor.dll` from this package.
  Your `gearbox` folder and its stock server are not used by this package.
- `gearbox_addon\ui\`, `gearbox_addon\resource\`: BHL menus and the English menu text.
  The Advanced > About page has no auto-update option.
- `gearbox_addon\delta.lst`: network field table used by this client build.
- `gearbox_addon\op4weapons.cfg` and `gearbox_addon\cfg\op4weapons.cfg`: optional cheat script (needs `sv_cheats 1`).
- `LICENSES\`: GPL-3.0 (BugfixedHL), Valve Half-Life 1 SDK License, and MIT (build tools).

## Defaults

- Main HUD color, HUD numbers, and crosshair use the original Opposing Force green (0 160 0).
  The first start with this build sets these once. You can change them later in the Advanced menu.
- `sv_cheats` is set to 0 at every start.

## What changed in this build (not yet tested in game)

- Addon-12: `impulse 101` gives the nine OP4 weapons (eagle, pipewrench, m249, displacer, shockrifle, sporelauncher, sniperrifle, knife, grapple), with no penguin and no extra ammo. Server and client built by CI run 45077036714 from commit 3fc35c2, not yet tested in game.
- Addon-13: server fix for the 'ScoreInfo: 5 bytes written, expected 9' error on coop/CTF maps (9-byte ScoreInfo). `gearbox_addon/mapcycle.txt` lists multiplayer maps only (op4_*, op4cp_*, op4ctf_*). Server and client built by CI run 45082482634 from commit f4bba30; not yet tested in game.
- Addon-14: `liblist.gam` adds `mpfilter "of"`, so the Create Server map list hides the Opposing Force story maps (`of*`, `ofboot*`). Multiplayer maps (`op4_*`, `op4cp_*`, `op4ctf_*`) stay listed. Stock Half-Life maps are not affected by this key. Client and server DLLs are the same as addon-13 (not rebuilt). Not yet tested in game.
- Addon-15: Advanced > Multiplayer > Models: a scrollbar (and mouse wheel) so the lower options (Hide corpses, Left-handed weapons, Angle weapon when moving, Disable weapon shells, Hide weapon view model) can be reached. Client and server built by CI run 45086486744 from commit d3d5436; not yet tested in game.
- Addon-10 (version 1.0.0): ships the server DLL (`gearbox_addon\dlls\opfor.dll`) together with the client, so the Pipe Wrench fire2 change reaches the server. The server is the `hl.dll` of the BHL-based tree (`bhl-op4/`), renamed to `opfor.dll`, from the same CI build as the client (commit 0fc00ee). Not yet tested in game.
- Pipe Wrench fire2 changed from OP4 Updated, as requested. Holding fire2 keeps the wrench pulled back and loops the hold animation with no strike. Releasing strikes: the pull-back must finish first (1.0 s). Damage is 25 + 20 x charge time, charge clamped to 1.0-6.25 s (45 to 150). The formula and the 150 cap come from a third-party source and are not verified.
- Pipe Wrench: the big-swing post delay is 1.0 s (OP4 Updated value). The fallback damage is 20 when `sk_plr_pipewrench` is 0 or below. Both were chosen by the agent under the user's delegation; they are not from the spec.
- Pipe Wrench: fixed the client resetting the swing mode each frame, which could make the wrench pull back and forth while fire2 is held.
- Addon-9 (version 1.0.0): Pipe Wrench fire2 changed from OP4 Updated, as requested. Holding fire2 keeps the wrench pulled back and loops the hold animation with no strike. Releasing strikes: the pull-back must finish first (1.0 s). Damage is 25 + 20 x charge time, charge clamped to 1.0-6.25 s (45 to 150). Delay after a big swing is 0.7 s. The formula and the 150 cap come from a third-party source and are not verified. Built by CI from commit 7f003d7, not yet tested in game.
- Addon-8 (version 1.0.0): this package contains only the client DLL. The server is still the stock `gearbox\dlls\opfor.dll`. Speedrun-batch changes that are server-side (ropes, monsters, func_pushable, skill damage defaults, and server weapon damage) are NOT in this package. Client-side changes from the same batch and from the Pipe Wrench, Knife, and M249 timing reverts are in `client.dll`. Built by CI from commit 81bcf05, not yet tested in game.
- Advanced > HUD Color > "Main color": default is the original OP4 green (0 160 0). Existing settings are reset to green once.
- Crosshair default color: original OP4 green (0 160 0).
- `sv_cheats` is set to 0 at every start.
- Spore Launcher: its weapon name is set on the client, which the other OP4 weapons already had.
- Weapon prediction: ammo type and count are kept per active weapon. Before, every weapon object received the active weapon's ammo values.
- Weapon ID fix (addon-5): Sniper, Spore Launcher, and Shock Roach now use the stock OP4 server weapon IDs (Shock 22, Spore 23, Sniper 24, Knife 25, Penguin 26). Before, the client predicted the wrong weapon for these IDs, which caused the sound and effect mix-up. Built by CI, not yet tested in game.
- Shock Rifle right button (addon-6): plays the Shock Rifle IDLE3 animation. No shot and no projectile. Built by CI, not yet tested in game.
- Lambda fix (addon-7): version 1.0.0. The About page has the title "Lambda fix", a GitHub link to https://github.com/Abdo-X684/Lambda-fix, a licenses button, and "Built on BHL Rebased" at the bottom. Update checks are disabled: the game does not contact GitHub and shows no update messages. Console commands renamed: lambda_apply_defaults, lambda_validate_files, lambda_defaults_version (the old bhl_ names are gone). Built by CI, not yet tested in game.

## Weapon test (please report each line)

1. Pick up / select Sniper Rifle: does it fire as a sniper rifle (bullet, scope, sound, model in hand)?
2. Select Spore Launcher: does it fire spores (projectile, sound, model in hand)?
3. Select Shock Roach / Shock Rifle: does it fire the shock rifle (beam, roach, model in hand)?
4. Does the ammo count go down and up correctly for each weapon? Does the HUD icon match the weapon?
5. Any console errors or crashes? Send the last lines of the console.

## Notes

- This package contains no Valve assets. Maps, models, and sounds come from your `gearbox\` folder (fallback).
- Music comes from your installed OP4 `gearbox\media`. No MP3 files are in this package.
- Your `gearbox\` folder is not modified by this package. To undo, delete the `gearbox_addon\` folder.
- This Windows package was built by CI but was not run in a Windows game session by the maintainer.
  Test results are listed in `RUNTIME_TESTS.md`. Only what was reported as working is marked as working.
- If you get an error, send the last lines of the console output.
