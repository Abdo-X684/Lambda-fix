# Lambda-fix: Lambda + Opposing Force (Windows)

This package is an overlay for your installed Opposing Force. It does not create a new game folder.
The game runs as `gearbox`, so models, sounds, maps, and music come from your own OP4 install.

## Install

1. Install Half-Life: Opposing Force (Steam or an original copy).
2. Back up your `gearbox\` folder (copy it somewhere safe). This package replaces a few files in it.
3. Unzip this package into the main Half-Life folder, next to `valve\` and `gearbox\`.
   The zip contains a `gearbox\` folder. Let Windows merge it, and overwrite files when asked.
4. Launch Opposing Force as usual, or run `hl.exe -game gearbox`.
   Typing `gamedir` in the console should print `gearbox`.

## Requirements

- Windows 10 or 11. The GoldSrc engine and this client DLL are both 32-bit (Win32).
- Half-Life: Opposing Force installed.
- No separate SDL2 install is needed. The client DLL does not import SDL2.dll.

## What is inside

- `gearbox\cl_dlls\client.dll`: Lambda client (based on BugfixedHL) with the Opposing Force weapons,
  built with MSVC 2022 (Win32). Source: `bhl-op4/` in the Lambda-fix repository.
- The server is the stock `gearbox\dlls\opfor.dll` from your installed game. This package does not replace it.
- `gearbox\ui\`, `gearbox\resource\`: BHL menus and the English menu text.
  The Advanced > About page has no auto-update option.
- `gearbox\delta.lst`: network field table used by this client build.
- `gearbox\op4weapons.cfg` and `gearbox\cfg\op4weapons.cfg`: optional cheat script (needs `sv_cheats 1`).
- `LICENSES\`: GPL-3.0 (BugfixedHL), Valve Half-Life 1 SDK License, and MIT (build tools).
  `NOTICE.txt` explains the source of each part.

## Defaults

- Main HUD color, HUD numbers, and crosshair use the original Opposing Force green (0 160 0).
  The first start with this build sets these once. You can change them later in the Advanced menu.
- `sv_cheats` is set to 0 at every start.

## Notes

- This package contains no Valve assets. Maps, models, and sounds come from `gearbox\`.
- Music comes from your installed OP4 `gearbox\media`. No MP3 files are in this package.
- This Windows package was built by CI but was not run in a Windows game session by the maintainer.
  Test results are listed in `RUNTIME_TESTS.md`. Only what was reported as working is marked as working.
- To undo: restore your backup of `gearbox\`, or verify the game files in Steam.
- If you get an error, send the last lines of the console output.
