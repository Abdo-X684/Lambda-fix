# Lambda-fix: Lambda + Opposing Force (Windows)

This package is a separate game folder, `gearbox_addon`, next to your `valve` and `gearbox` folders.
It uses your installed Opposing Force for maps, models, sounds, and music. Your `gearbox` folder is not changed.

## Install

1. Install Half-Life: Opposing Force (Steam or an original copy).
2. Unzip this package into the main Half-Life folder, next to `valve\` and `gearbox\`.
   The zip contains a `gearbox_addon\` folder. It should end up at `Half-Life\gearbox_addon\`.
3. Launch with `hl.exe -game gearbox_addon`.
   Typing `game` or `gamedir` in the console should show `gearbox_addon`.

## Requirements

- Windows 10 or 11. The engine and this client DLL are both 32-bit (Win32).
- Half-Life: Opposing Force installed.
- No separate SDL2 install is needed. The client DLL does not import SDL2.dll.

## What is inside

- `gearbox_addon\cl_dlls\client.dll`: Lambda client (based on BugfixedHL) with the Opposing Force weapons,
  built with MSVC 2022 (Win32). Source: `bhl-op4/` in the Lambda-fix repository.
- `gearbox_addon\liblist.gam`: game definition. The server is the stock `gearbox\dlls\opfor.dll`
  from your installed game; this package does not replace it.
- `gearbox_addon\ui\`, `gearbox_addon\resource\`: BHL menus and the English menu text.
  The Advanced > About page has no auto-update option.
- `gearbox_addon\delta.lst`: network field table used by this client build.
- `gearbox_addon\op4weapons.cfg` and `gearbox_addon\cfg\op4weapons.cfg`: optional cheat script (needs `sv_cheats 1`).
- `LICENSES\`: GPL-3.0 (BugfixedHL), Valve Half-Life 1 SDK License, and MIT (build tools).

## Defaults

- Main HUD color, HUD numbers, and crosshair use the original Opposing Force green (0 160 0).
  The first start with this build sets these once. You can change them later in the Advanced menu.
- `sv_cheats` is set to 0 at every start.

## What changed in this build (not yet tested in game)

- Advanced > HUD Color > "Main color": default is the original OP4 green (0 160 0). Existing settings are reset to green once.
- Crosshair default color: original OP4 green (0 160 0).
- `sv_cheats` is set to 0 at every start.
- Spore Launcher: its weapon name is set on the client, which the other OP4 weapons already had.
- Weapon prediction: ammo type and count are kept per active weapon. Before, every weapon object received the active weapon's ammo values.
- Weapon ID fix (addon-5): Sniper, Spore Launcher, and Shock Roach now use the stock OP4 server weapon IDs (Shock 22, Spore 23, Sniper 24, Knife 25, Penguin 26). Before, the client predicted the wrong weapon for these IDs, which caused the sound and effect mix-up. Built by CI, not yet tested in game.

## Weapon test (please report each line)

1. Pick up / select Sniper Rifle: does it fire as a sniper rifle (bullet, scope, sound, model in hand)?
2. Select Spore Launcher: does it fire spores (projectile, sound, model in hand)?
3. Select Shock Roach / Shock Rifle: does it fire the shock rifle (beam, roach, model in hand)?
4. Does the ammo count go down and up correctly for each weapon? Does the HUD icon match the weapon?
5. Any console errors or crashes? Send the last lines of the console.

## Notes

- This package contains no Valve assets. Maps, models, and sounds come from your `gearbox\` folder (fallback).
- Music comes from your installed OP4 `gearbox\media`. No MP3 files are in this package.
- Your `gearbox\` folder is not modified by this package. To undo, delete the `gearbox_addon\` folder.
- This Windows package was built by CI but was not run in a Windows game session by the maintainer.
  Test results are listed in `RUNTIME_TESTS.md`. Only what was reported as working is marked as working.
- If you get an error, send the last lines of the console output.
