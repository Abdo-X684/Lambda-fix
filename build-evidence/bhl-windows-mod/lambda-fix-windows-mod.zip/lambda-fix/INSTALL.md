# lambda-fix — Lambda + Opposing Force (Windows)

## Install

1. Install Half-Life: Opposing Force (Steam or an original copy). The `gearbox\` folder must sit next to `valve\`.
2. Delete any old `lambda-fix` folder.
3. Unzip this package into the main game folder, next to `valve\` and `gearbox\`
   (example: `Half-Life\lambda-fix\`). Do not put it inside `gearbox\`. Do not rename it.
4. Launch Half-Life with `-game lambda-fix` (for example: `hl.exe -game lambda-fix`).

## Requirements

- Windows 10 or 11. The GoldSrc engine and this client DLL are both 32-bit (Win32).
- Half-Life: Opposing Force installed. Maps, models, and sounds are read from `gearbox\`.
- No separate SDL2 install is needed. The client DLL does not import SDL2.dll.

## What is inside

- `cl_dlls\client.dll`: Lambda client (based on BugfixedHL) with the Opposing Force weapons,
  built with MSVC 2022 (Win32). Source: `bhl-op4/` in the Lambda-fix repository.
- Server: the stock `gearbox\dlls\opfor.dll` from your installed game is used.
- `ui\resource\`: BHL menus. The Advanced > About page has no auto-update option.
  The default HUD color is green.
- `resource\lambda-fix_english.txt`: English localization for menu text.
- `LICENSES\`: GPL-3.0 (BugfixedHL), Valve Half-Life 1 SDK License, and MIT (build tools).
  `NOTICE.txt` explains the source of each part.

## Notes

- This package contains no Valve assets. Maps, models, and sounds come from `gearbox\`.
- Music: the package has no MP3 files. Music comes from your installed OP4 `gearbox\media`.
- This Windows package was built by CI but was not run in a Windows game session by the maintainer.
  Test results are listed in `RUNTIME_TESTS.md`. Only what was reported as working is marked as working.
- If you get an error, send the last lines of the console output.
