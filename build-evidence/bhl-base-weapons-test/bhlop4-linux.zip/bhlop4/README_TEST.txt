Folder name MUST be bhlop4 (not gearbox_addon: the engine rejects names starting with gearbox/valve).
Contents: cl_dlls (client.so, vgui.so, libSDL2), dlls/hl.so, liblist.gam, resource/GameMenu.res.
Install: copy this folder to Half-Life/bhlop4. Launch: -game bhlop4 -console.
NOT TESTED IN GAME.
