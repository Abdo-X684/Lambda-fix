BHL + OP4 Linux client (rebuilt set, replaces the earlier test set)

Why it changed: the earlier client.so needed libtier0.so and libvstdlib.so,
which are not in a normal game folder -> "could not load library".
This set's client.so needs only vgui.so and libSDL2-2.0.so.0, and both are
included in cl_dlls/. tier0/vstdlib: 0 undefined references.

Install (back up your current files first):
1. Copy cl_dlls/ (client.so, vgui.so, libSDL2-2.0.so.0) into your game folder's cl_dlls/.
2. Copy dlls/hl.so into your game folder's dlls/.
3. Launch with -game bhlop4 -console (or your folder name).

NOT TESTED IN GAME. Report: does it start, and the console text if it fails.
